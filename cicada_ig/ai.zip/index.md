# Cicada IG Home - The Cicada Vaccine Forecasting Engine and Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Cicada IG Home**

## Cicada IG Home

| | |
| :--- | :--- |
| *Official URL*:http://fhirfli.dev/fhir/ig/cicada/ImplementationGuide/cicada.ig | *Version*:0.1.0 |
| Draft as of 2026-09-07 | *Computable Name*:CicadaIG |

# Cicada IG

## 100% Credit goes to the CDC and their Clinical Decision Support for Immunization (CDSi)

All I've done is take all of their hard work, guidance and expertise and make it computable (well, perhaps it's already computable, I made a computer actually do it).

The CDSi Logic Specification can be found on the [CDC CDSi page](https://www.cdc.gov/iis/cdsi/). The current supporting data version implemented is **4.61-508**.

First, a warning: This is not completely FHIR compliant. As part of this was to help myself get more familiar with [FHIR Shorthand (commonly known as FSH)](https://build.fhir.org/ig/HL7/fhir-shorthand/), there are some "Resources" I've defined (e.g. [Antigen Supporting Data](StructureDefinition-AntigenSupportingData.md) and [Schedule Supporting Data](StructureDefinition-ScheduleSupportingData.md)), that are certainly NOT FHIR. However, they are an accurate representation (at least in JSON) for the data used in the CDC's "CLINICAL DECISION SUPPORT FOR IMMUNIZATION (CDSI): LOGIC SPECIFICATION FOR ACIP RECOMMENDATIONS".

### Preparation

* Technical background on the code generator and build pipeline for anyone interested in working on this themselves.

### Immunization Decision Support Forecast Working Group

* Because I can never find it
* Official HL7 working group

### Logical Specification Concepts

* There are a number of concepts that are involved in the evaluation and prediction of immunizations. Some of these terms make logical sense, but others do not. Here's a description of some of them. Again, this was all taken from the [Clinical Decision Support for Immunization (CDSi)](https://www.cdc.gov/iis/cdsi/).

### Processing Model

* Brief overview of the analysis and forecasting process prior to a detailed discussion.

### Evaluate Vaccine Dose Administered

* Summarizes the steps to evaluate every vaccine within every series to which it applies.

### Forecast Dates and Reasons

* Made it through the evaluation process. Next up, creating the forecast.

### Select Patient Series

* After evaluating and forecasting, we need to pick the best series for each antigen. This covers pre-filtering, prioritization, scoring, and final selection. 

### Dependencies and terminology

 




*There are no Global profiles defined*

* Parameter: system-version
  * Value: SNOMED CT[US]

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (cicada.ig.r4)](package.r4.tgz) and [R4B (cicada.ig.r4b)](package.r4b.tgz) are available.

### Intellectual property

This publication includes IP covered under the following statements.

* Current Procedural Terminology (CPT) is copyright 2020 American Medical Association. All rights reserved

* [CPT](http://tx.fhir.org/r4/ValueSet/x-cpt2023): [ImmunizationProceduresCpt](ValueSet-immunization-procedures-cpt.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://tx.fhir.org/r4/ValueSet/x-loinc2.82): [CicadaImmunizationRecommendation](StructureDefinition-cicada-immunization-recommendation.md), [ForecastStatusVS](ValueSet-forecast-status.md), [ImmunizationRecommendation/cicada-forecast-example](ImmunizationRecommendation-cicada-forecast-example.md) and [VaccineLabEvidenceOfImmunityLoinc](ValueSet-vaccine-lab-evidence-of-immunity-loinc.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AllergyIntolerance/allergy-vaccine-reaction](AllergyIntolerance-allergy-vaccine-reaction.md), [Condition/2016-UC-0032-055](Condition-2016-UC-0032-055.md)... Show 13 more, [ImmunizationEvaluation/2016-UC-0032-1](ImmunizationEvaluation-2016-UC-0032-1.md), [ImmunizationEvaluation/2016-UC-0032-2](ImmunizationEvaluation-2016-UC-0032-2.md), [ImmunizationEvaluation/2016-UC-0032-3](ImmunizationEvaluation-2016-UC-0032-3.md), [ImmunizationProceduresSnomed](ValueSet-procedures.md), [ImmunizationRecommendation/cicada-forecast-example](ImmunizationRecommendation-cicada-forecast-example.md), [Observation/observation-immunocompromised](Observation-observation-immunocompromised.md), [Procedure/procedure-stem-cell-transplant](Procedure-procedure-stem-cell-transplant.md), [ProcedureProfile](StructureDefinition-ProcedureProfile.md), [ReactionProfile](StructureDefinition-ReactionProfile.md), [VaccineConditionCodesSnomed](ValueSet-vaccine-condition-codes-snomed.md), [VaccineConditionFhir](StructureDefinition-VaccineConditionFhir.md), [VaccineMedicationCodesSnomed](ValueSet-vaccine-medication-codes-snomed.md) and [VaccineObservationFhir](StructureDefinition-VaccineObservationFhir.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.3.0/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/allergy-vaccine-reaction](AllergyIntolerance-allergy-vaccine-reaction.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.3.0/CodeSystem-condition-clinical.html): [Condition/2016-UC-0032-055](Condition-2016-UC-0032-055.md)
* [Immunization Evaluation Dose Status codes](http://terminology.hl7.org/7.3.0/CodeSystem-immunization-evaluation-dose-status.html): [EvalStatusVS](ValueSet-eval-status.md), [ImmunizationEvaluation/2016-UC-0032-1](ImmunizationEvaluation-2016-UC-0032-1.md), [ImmunizationEvaluation/2016-UC-0032-2](ImmunizationEvaluation-2016-UC-0032-2.md) and [ImmunizationEvaluation/2016-UC-0032-3](ImmunizationEvaluation-2016-UC-0032-3.md)
* [Immunization Recommendation Status Codes](http://terminology.hl7.org/7.3.0/CodeSystem-immunization-recommendation-status.html): [CicadaImmunizationRecommendation](StructureDefinition-cicada-immunization-recommendation.md), [ForecastStatusVS](ValueSet-forecast-status.md) and [ImmunizationRecommendation/cicada-forecast-example](ImmunizationRecommendation-cicada-forecast-example.md)
* [Immunization Subpotent Reason](http://terminology.hl7.org/7.3.0/CodeSystem-immunization-subpotent-reason.html): [VaxDose](StructureDefinition-vax-dose.md)



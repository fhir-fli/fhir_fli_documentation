# Forecast Status Value Set - The Cicada Vaccine Forecasting Engine and Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Forecast Status Value Set**

## ValueSet: Forecast Status Value Set 

| | |
| :--- | :--- |
| *Official URL*:http://fhirfli.dev/fhir/ig/cicada/ValueSet/forecast-status | *Version*:0.1.0 |
| Draft as of 2026-09-07 | *Computable Name*:ForecastStatusVS |

 
Combined value set for immunization forecast status, referencing published standard CodeSystems. Includes ImmDS IG ForecastStatus (CDSi-compatible), HL7 THO immunization-recommendation-status, and LOINC answer list LL940-8. 

 **References** 

* [Cicada Immunization Recommendation](StructureDefinition-cicada-immunization-recommendation.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "forecast-status",
  "url" : "http://fhirfli.dev/fhir/ig/cicada/ValueSet/forecast-status",
  "version" : "0.1.0",
  "name" : "ForecastStatusVS",
  "title" : "Forecast Status Value Set",
  "status" : "draft",
  "date" : "2026-09-07T18:40:23-04:00",
  "publisher" : "FHIR-FLI",
  "contact" : [{
    "name" : "FHIR-FLI",
    "telecom" : [{
      "system" : "url",
      "value" : "http://fhirfli.dev"
    }]
  }],
  "description" : "Combined value set for immunization forecast status, referencing published standard CodeSystems. Includes ImmDS IG ForecastStatus (CDSi-compatible), HL7 THO immunization-recommendation-status, and LOINC answer list LL940-8.",
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/us/immds/CodeSystem/ForecastStatus"
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/immunization-recommendation-status"
    },
    {
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "LA13421-5",
        "display" : "Complete - all required doses have been received to meet the requirements for a particular vaccine group."
      },
      {
        "code" : "LA13422-3",
        "display" : "On schedule - person is not overdue for a given dose in the series. Includes a person too young to start the series."
      },
      {
        "code" : "LA13423-1",
        "display" : "Overdue - person is late getting the next dose in the series."
      },
      {
        "code" : "LA27183-5",
        "display" : "Immune"
      },
      {
        "code" : "LA4216-3",
        "display" : "Contraindicated"
      },
      {
        "code" : "LA4695-8",
        "display" : "Not Recommended"
      },
      {
        "code" : "LA13424-9",
        "display" : "Too old - cannot complete the series because the latest age for receiving dose has passed."
      }]
    }]
  }
}

```
